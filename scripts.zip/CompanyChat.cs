/*
*Title: Company Chat File
*Created: December 28, 2017 (3:53 AM)
*Description: For the purpose of chatting yo
*/

/*--START BELOW THIS LINE--*/
/* Todo's
*make GUIs Fluent & appealing
*get example humanoid object frm lane. camera angle n collisions
*get toon setup complete
*goal end date for setup jan 11
*bring on second animator
*determine exact stakes in game company/revenue from projects
*/