using UnityEngine;
using System.Collections;

public class TestGUI : MonoBehaviour {
	
	private BaseToonClasses class1 = new 
	
	
	void Start (){
		
		
	}
	
	void Update () {
		
	
	}
	
	void OnGUI(){
		
		
	}
}